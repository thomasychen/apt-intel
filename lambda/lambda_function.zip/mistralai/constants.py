RETRY_STATUS_CODES = {429, 500, 502, 503, 504}

ENDPOINT = "https://api.mistral.ai"

HEADER_MODEL_DEPRECATION_TIMESTAMP = "x-model-deprecation-timestamp"
