"""
Custom exceptions for good ol haralyzer.
"""


class PageNotFoundError(AttributeError):
    """Error raised in the Page is not found"""
